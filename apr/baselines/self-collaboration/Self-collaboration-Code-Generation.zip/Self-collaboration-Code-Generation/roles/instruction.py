INSTRUCTPLAN = "The plan from the requirement analyst is as following:\n{report}"
INSTRUCTREPORT = "The report from the tester is as following:\n{report}"
INSTRUCTCODE = "Please implement the following code. Use ```python to put the Python code in markdown quotes:\n{requirement}"
INSTRUCTEST = "The code provided by developer is as follows:\n{code}\n"


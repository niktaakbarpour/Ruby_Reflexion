python evaluate/eval_apr.py --base-dir /root/Self-collaboration-Code-Generation

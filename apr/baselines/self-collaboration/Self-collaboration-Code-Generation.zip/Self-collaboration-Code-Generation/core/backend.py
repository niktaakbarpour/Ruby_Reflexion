import openai
import time
import os
import re

# openai.api_key = os.environ.get("API_KEY", "your-api-key")
# openai.api_base = os.environ.get("API_BASE", "your-api-base")

# def call_chatgpt(messages, model=None, stop=None, temperature=1.0, top_p=1.0,
#         max_tokens=4096, echo=False, majority_at=None):
    
#     model = os.environ.get("MODEL_NAME", "deepseek-chat")
    
#     num_completions = majority_at if majority_at is not None else 1
#     num_completions_batch_size = 10

#     completions = []
#     for i in range(20 * (num_completions // num_completions_batch_size + 1)):
#         try:
#             requested_completions = min(num_completions_batch_size, num_completions - len(completions))

#             response = openai.ChatCompletion.create(
#                 model=model,
#                 messages=messages,
#                 max_tokens=max_tokens,
#                 temperature=temperature,
#                 top_p=top_p,
#                 n=requested_completions,
#                 frequency_penalty=0.0,
#                 presence_penalty=0.0,
#             )
            
#             completions.extend([choice.message.content for choice in response.choices])
#             if len(completions) >= num_completions:
#                 return completions[:num_completions]
                
#         except openai.error.RateLimitError as e:
#             print(f"Rate limit hit, waiting {min(i**2, 60)} seconds...")
#             time.sleep(min(i**2, 60))
#         except Exception as e:
#             print(f"Error occurred: {e}")
#             time.sleep(min(i**2, 60))
            
#     raise RuntimeError('Failed to call GPT API after multiple attempts')


def call_chatgpt(
    messages,
    model=None,
    stop=None,
    temperature=1.0,
    top_p=1.0,
    max_tokens=4096,
    echo=False,           # ChatCompletion doesn't support echo; kept for signature compatibility
    majority_at=None
):
    """
    Same inputs as your original call_chatgpt.
    Returns:
      - if majority_at in {None, 1}: a single dict in the 'gen' style
      - if majority_at > 1: a list of such dicts
    """

    # ---- helpers ----
    def _strip_special_tokens(text: str) -> str:
        pats = [
            r"<\|EOT\|>", r"<\|endoftext\|>",
            r"<｜begin▁of▁sentence｜>", r"<｜end▁of▁sentence｜>"
        ]
        for pat in pats:
            text = re.sub(pat, "", text)
        text = re.sub(r"<\|[^>]*\|>", "", text)
        text = re.sub(r"<｜[^>]*｜>", "", text)
        return text.strip()

    def _extract_output(content: str) -> str:
        # mirrors a typical llm.extract_output: prefer first fenced code block
        text = _strip_special_tokens(content)
        if "```" in text:
            parts = text.split("```")
            if len(parts) >= 2:
                return f"```{parts[1]}```".strip()
        return text  # fallback to full text

    # ---- config ----
    model = model or os.environ.get("MODEL_NAME", "deepseek-chat")
    num_completions = majority_at if majority_at is not None else 1
    num_completions_batch_size = 10

    # last user prompt text (for the 'prompt' field)
    prompt_text = ""
    for m in reversed(messages):
        if m.get("role") == "user":
            prompt_text = m.get("content", "")
            break

    completions = []
    cnt = 0

    # keep trying until we gather all requested completions or hit the retry cap
    while cnt < 999 and len(completions) < num_completions:
        try:
            requested = min(num_completions_batch_size, num_completions - len(completions))
            resp = openai.ChatCompletion.create(
                model=model,
                messages=messages,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                n=requested,
                stop=stop,
                # echo is not supported for ChatCompletion; ignored to keep signature
                frequency_penalty=0.0,
                presence_penalty=0.0,
            )
            for choice in resp.choices:
                completions.append(choice.message.content)
                if len(completions) >= num_completions:
                    break

        except openai.error.RateLimitError as e:
            cnt += 1
            wait_time = min(cnt**2, 60)
            print(f"Rate limit hit, waiting {wait_time} seconds...")
            time.sleep(wait_time)
        except Exception as e:
            cnt += 1
            wait_time = min(cnt**2, 60)
            print(f"Error occurred (attempt {cnt}): {e}")
            time.sleep(wait_time)

    if not completions:
        raise RuntimeError("Failed to call GPT API after multiple attempts")

    # --- normalize like `gen` and add extraction ---
    results = []
    for comp in completions:
        try:
            fixed = _extract_output(comp)
        except Exception as e:
            print(f"Extract error: {e}")
            fixed = ""
        results.append({
            "choices": [{"message": {"role": "assistant", "content": comp}}],
            "fixed_source_code": fixed,
            "prompt": prompt_text
        })

    return results[0] if num_completions == 1 else results
